/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bo;

/**
 *
 * @author vananh
 */
public class Course implements Comparable<Course>{

    private String code, name;
    private int credit;

    public Course(String code, String name, int credit) {
        this.code = code;
        this.name = name;
        this.credit = credit;
    }

    public Course() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCredit() {
        return credit;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }

    @Override
    public int compareTo(Course o) {
        if (o.credit == this.credit) {
            return 1;
        } else if (o.credit < this.credit) {
            return 0;
        } else {
            return -1;
        }
    }

    @Override
    public String toString() {
        return code + " | " + name + " | " + credit + '\n';
    }

}
