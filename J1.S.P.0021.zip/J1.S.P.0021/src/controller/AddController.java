/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import bo.Course;
import frame.AddCourse;
import java.util.List;
import javax.swing.JOptionPane;


/**
 *
 * @author vananh
 */
public class AddController {
    
    AddCourse add;
    List<Course> cList;
    
    public AddController(AddCourse add, List<Course> cList) {
        this.add = add;
        this.cList = cList;
        add.setLocationRelativeTo(add);
        add.setResizable(false);
    }
    
    public void addCourse() {
        String name = add.getTxtName().getText().trim().toLowerCase();
        String code = add.getTxtCode().getText().trim();
        String credit = add.getTxtCredit().getText().trim();
        
        Utility u = new Utility();
        if(!u.checkForm(code)) {
            JOptionPane.showMessageDialog(add, "Code can't empty");
        } else if(!cList.isEmpty() && u.checkCode(code, cList) >= 0) {
            JOptionPane.showMessageDialog(add, "This code already exist");
        } else if(!u.checkEmpty(name)) {
            JOptionPane.showMessageDialog(add, "Name can't empty");
        } else if(!u.checkEmpty(credit)) {
            JOptionPane.showMessageDialog(add, "Credit can't empty");
        } else {
            try {
                int creditNum = Integer.parseInt(credit);
                if(!u.checkCredit(creditNum)) {
                    JOptionPane.showMessageDialog(add, "Credit must be a positive number and less than or equals to 33");
                } else {
                    String normalName = u.normalization(name);
                    cList.add(new Course(code, normalName, creditNum));
                    JOptionPane.showMessageDialog(add, "Add Successfully");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(add, "Credit must be a positive number and less than or equals to 33");
            }
        }
    }
}
