/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import bo.Course;
import frame.SearchCourse;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author vananh
 */
public class SearchController {

    SearchCourse search;
    List<Course> cList;

    public SearchController(SearchCourse search, List<Course> cList) {
        this.search = search;
        this.cList = cList;
        search.setLocationRelativeTo(search);
        search.setResizable(false);
    }

    public void searchCourse() {
        int exist = Utility.checkCode(search.getTxtSCode().getText(), cList);
        if (exist >= 0) {
            search.getTxtSName().setText(cList.get(exist).getName());
            search.getTxtSCredit().setText(cList.get(exist).getCredit() + "");
        } else {
            JOptionPane.showMessageDialog(search, "Not found!!!");
        }
    }
}
