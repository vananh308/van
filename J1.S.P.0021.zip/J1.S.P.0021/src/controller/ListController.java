/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import bo.Course;
import frame.ListCourse;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author vananh
 */
public class ListController {
    ListCourse list;
    List<Course> cList;

    public ListController(ListCourse list, List <Course> cList) {
        this.list = list;
        this.cList = cList;
        list.setLocationRelativeTo(list);
        list.setResizable(false);
        listCourse();
    }
    
    public void listCourse() {
       Collections.sort(cList);
       for(Course c : cList) {
           list.getTaList().append(c.toString());
       }
        
    }
}
