/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import bo.Course;
import java.util.List;

/**
 *
 * @author vananh
 */
public class Utility {

    public static boolean checkEmpty(String txt) {
        if (txt.equals("")) {
            return false;
        }
        return true;
    }

    public static boolean checkForm(String value) {
        if (value.matches("^[a-zA-Z0-9]+$")) {
            return true;
        }
        return false;
    }

    public static boolean checkCredit(int value) {
        if (value < 0 || value > 33) {
            return false;
        }
        return true;
    }

    public static int checkCode(String code, List<Course> cList) {
        for (int i = 0; i < cList.size(); i++) {
            if (code.equalsIgnoreCase(cList.get(i).getCode())) {
                return i;
            }
        }
        return -1;
    }

    public String normalization(String s) {
        String[] nameSplit = s.split("\\s+");
        String nameNormal = "";
        char[] chars = null;
        for(int i = 0; i < nameSplit.length; i++) {
            chars = nameSplit[i].toCharArray();
            for(int j = 0; j < chars.length; j++) {
                if(!Character.isLetter(chars[j])) {
                    chars[j+1] = Character.toUpperCase(chars[j+1]);
                }
            }
            chars[0] = Character.toUpperCase(chars[0]);
            nameNormal += String.valueOf(chars) + " ";
        }
        return nameNormal;
    }
    
}
