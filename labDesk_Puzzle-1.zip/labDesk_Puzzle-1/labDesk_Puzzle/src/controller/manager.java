/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import static java.lang.Math.random;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import view.PuzzleGUI;

/**
 *
 * @author admin
 */
public class manager {

    PuzzleGUI viewPuzzle;
    int size = 3;
    int moveCount = 0;
    int elapseCount = 0;
    JButton[][] matrix; //moi ptu trong matrix btn dai dien cho 1 btn
    private boolean isStartGame = false;
    private Timer timer;

    public manager(PuzzleGUI viewPuzzle) {
        this.viewPuzzle = viewPuzzle;
        viewPuzzle.setResizable(false);
        createButton(size);
        newGame();
    }

    public void newGame() {
        viewPuzzle.getjBtNewGame().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                initEslaped();
                size = Integer.parseInt(viewPuzzle.getjSize().getSelectedItem().toString().split("x")[0]);
                createButton(size);
                moveCount = 0;
                viewPuzzle.getjMoveCount().setText("Move count: 0");
                elapseCount = 0;
                isStartGame = true;
            }
        });
    }
    
    public void createButton(int size) {
        this.size = size;
        viewPuzzle.getjPanel1().removeAll();
        int count = 0;
        //có hàng có cột là gridlayout
        GridLayout grid = new GridLayout(size, size, 10, 10);
        viewPuzzle.getjPanel1().setPreferredSize(new Dimension(size * 60, size * 60)); //chieu rong va chieu cao
        viewPuzzle.getjPanel1().setLayout(grid);
        matrix = new JButton[size][size];
        for (int i = 0; i < size; i++) { //chay hang 
            for (int j = 0; j < size; j++) { //chay cot
                count++;
                JButton bt = new JButton(count + "");
                matrix[i][j] = bt;
                //JButton bt= new JButton(i * 3 + j + 1 + "");
                // 1 2 3
                viewPuzzle.getjPanel1().add(bt);
                //add action to all button
                bt.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        if (isStartGame) {
                            if (checkMoveButton(bt)) {
                                moveButton(bt);
                                moveCount++;
                                viewPuzzle.getjMoveCount().setText("Move count: " + moveCount);
                                if (messWin()) {
                                    timer.stop();
                                    JOptionPane.showMessageDialog(null, "You won");
                                    isStartGame = false;                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "press new game");
                        }
                    }
                });
            }
        }
        matrix[size - 1][size - 1].setText("");
        //randomButton();
        viewPuzzle.pack(); // co dãn đúng với panel bên trong
    }

    //để thắng thì btn rỗng phải đổi với btn bên cạnh, đổi được khi cùng hàng cùng cột
    public Point getButtonEmpty() {
        int i = 0, j = 0;
        for (i = 0; i < size; i++) {
            for (j = 0; j < size; j++) {
                if (matrix[i][j].getText().equals("")) {
                    return new Point(i, j);
                }
            }
        }
        return null;
    }

    //random vẫn thắng vì chỉ đổi vs bt bên cạnh chứ k chéo
    public void randomButton() {
        for (int k = 0; k < 1000; k++) {
            Point p = getButtonEmpty(); //lấy tọa độ rỗng
            int i = p.x;
            int j = p.y;
            Random rd = new Random();
            int valueRandom = rd.nextInt(4); // 0 1 2 3
            switch (valueRandom) {
                case 0: {// up , ngang là j thẳng là i
                    if (i > 0) {
                        matrix[i][j].setText(matrix[i - 1][j].getText());
                        matrix[i - 1][j].setText("");
                        break;
                    }
                }
                case 1: {//down
                    if (i < size - 1) {
                        matrix[i][j].setText(matrix[i + 1][j].getText());
                        matrix[i + 1][j].setText("");
                        break;
                    }
                }
                case 2: {//right
                    if (j < size - 1) {
                        matrix[i][j].setText(matrix[i][j + 1].getText());
                        matrix[i][j + 1].setText("");
                        break;
                    }

                }
                case 3: {//left
                    if (j > 0) {
                        matrix[i][j].setText(matrix[i][j - 1].getText());
                        matrix[i][j - 1].setText("");
                        break;
                    }
                }
            }
        }
    }

    //trước khi di chuyển thì cần check xem có hợp lệ k
    public boolean checkMoveButton(JButton btn) {
        int i1 = 0, j1 = 0;
        int x = getButtonEmpty().x;
        int y = getButtonEmpty().y;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (btn.getText().equals(matrix[i][j].getText())) {
                    i1 = i;
                    j1 = j;
                    break;
                }
            }
        }
        //i bằng nhau và j hơn kém 1 đơn vị
        if ((x == i1 && ((j1 - 1) == y)) || (x == i1 && ((j1 + 1) == y))) {
            return true;
        }
        if ((y == j1 && (i1 - 1 == x)) || (y == j1 && (i1 + 1 == x))) {
            return true;
        }
        return false;
    }

    public void moveButton(JButton btn) {
        int i = getButtonEmpty().x;
        int j = getButtonEmpty().y;
        matrix[i][j].setText(btn.getText());
        btn.setText("");
    }

    //win khi tất cả các btn giống như khởi tạo ban đầu
    public boolean messWin() {
        if (matrix[size - 1][size - 1].getText().equalsIgnoreCase("")) {
            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    if (i == size - 1 && j == size - 1) {
                        break;
                    }
                    if (!matrix[i][j].getText().equals(String.valueOf(i * size + j + 1))) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
    public void initEslaped() {
        timer = new Timer(1000, new ActionListener() {
            int second = 0;
            @Override
            public void actionPerformed(ActionEvent ae) {
                viewPuzzle.getjElapsed().setText("Elapse : " + second + "(sec)");
                second++;
            }
        });
        timer.start();
    }
}
