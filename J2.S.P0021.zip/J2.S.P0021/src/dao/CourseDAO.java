/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bo.Course;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 *
 * @author vananh
 */
public class CourseDAO {
    private ArrayList<Course> courses;

    public CourseDAO(ArrayList<Course> list) {
        this.courses = list;
    }
    public Course checkCourseDuplicate(String code) {
        for(Course course : courses) {
            if(course.getCode().equals(code)) {
                return course;
            }
        }
        return null;
    }
    
    public boolean addCourse(Course course) {
        int firstValue = courses.size();
        courses.add(course);
        int secondValue = courses.size();
        if(firstValue < secondValue) {
            return true;
        }
        return false;
    }
    
    public boolean checkInputValues(String code, int mark) {
        return (Pattern.matches("^[A-Z0-9]+$", code) && mark == 1) 
                || (Pattern.matches("^[A-Za-z]+(\\[A-Za-z]+)*$", code) && mark == 2)
                || (Pattern.matches("^[0-9]+$", code) && mark == 3);
                
    }
    
    public String checkFormatString(String string) {
        String newString = "";
        newString += String.valueOf((string.charAt(0))).toUpperCase();
        for (int i = 0; i < string.length(); i++) {
            if (string.charAt(i) == ' ') {
                newString += " ";
                newString += String.valueOf(string.charAt(i + 1)).toUpperCase();
                i++;
                continue;
            }
            newString += String.valueOf(string.charAt(i)).toLowerCase();
        }
        return newString;
    }
}
