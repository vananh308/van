/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bo;

import gui.AddCourse;
import gui.CourseManagement;
import gui.ListCourse;
import gui.SearchCourse;
import java.util.ArrayList;

/**
 *
 * @author Thuy Trieu
 */
public class ControlManagement {

    private final CourseManagement courseManagement;
    private ArrayList<Course> arr = new ArrayList<>();
    private SearchCourse searchCourse = new SearchCourse();
    private ListCourse listCourse = new ListCourse();
    private AddCourse addCourse = new AddCourse();

    public ControlManagement(CourseManagement courseManagement) {
        this.courseManagement = courseManagement;
    }

    public void add() {
        addCourse.setArr(arr);
        addCourse.clear();
        addCourse.setVisible(true);
    }

    public void display() {
        listCourse.setVisible(true);
        listCourse.display(arr);
    }

    public void search() {
        searchCourse.setArray(arr);
        searchCourse.reset();
        searchCourse.setVisible(true);
    }

    public void exit() {
        System.exit(0);
    }
}
