/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bo;

import gui.SearchCourse;
import java.util.ArrayList;

/**
 *
 * @author Thuy Trieu
 */
public class ControlSearch {

    private SearchCourse searchCourse;
    private ArrayList<Course> arr;

    public ControlSearch(SearchCourse sc) {
        searchCourse = sc;
    }

    public void show() {
        searchCourse.setVisible(true);
    }

    public void setArr(ArrayList<Course> arr) {
        this.arr = arr;
    }

    public void clear(){
        searchCourse.setTxtCode("");
        searchCourse.setTxtName("");
        searchCourse.setTxtCredit("");
    }
    public void search(String code) {
        for (Course course : arr) {
            if (course.getCode().equalsIgnoreCase(code)) {
                searchCourse.setTxtName(course.getName());
                searchCourse.setTxtCredit("" + course.getCredit());
                return;
            }
        }
        searchCourse.setTxtName("Not Found");
        searchCourse.setTxtCredit("Not Found");
    }
}
